<?php

session_start();

$session = $_SESSION;
$request = $_REQUEST;


define('DB_HOST', 'localhost'); // ñåðâåð ÁÄ
define('DB_USER', 'cl215183_univerk'); // ëîãèí ÁÄ
define('DB_PASS', '75M5hXmB'); // ïàðîëü ÁÄ
define('DB_NAME', 'cl215183_univerk'); // èìÿ Á


// if (!$conn = mysql_connect(DB_HOST,DB_USER,DB_PASS)) {
//     echo 'не могу подключиться к серверу БД';
//         exit;
// }

// if (!mysql_select_db(DB_NAME)) {
//     echo 'не могу подключить БД';
//         exit;
// }

$opts = array(
    'user' => DB_USER,
    'pass' => DB_PASS,
    'db'   => DB_NAME
);

$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
?>